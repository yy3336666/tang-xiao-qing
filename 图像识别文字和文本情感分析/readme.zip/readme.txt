1. How long did you spend on the assignment?
I have spent 24 hours to do this assignment

2. What did you learn by doing this assignment?
I learnt, how to apply maximum likelihood extimation, Backoff and interpolation, absoluter discounting, Kneser-Ney Smoothing in language processing. 

3. Briefly describe a Computational Text Analysis/Text as Data research question where language modeling would be useful (keep this answer to a maximum of 3 sentences).
Computational Text Analysis/Text as Data research often involves using large amounts of unstructured text data to extract insights and make predictions. One example of a research question where language modeling would be useful is predicting the sentiment of customer reviews for a product, which requires understanding the meaning and context of the words in the reviews. A language model trained on a large corpus of text can be used to analyze the sentiment of the reviews and make accurate predictions.